/* Paste your Web API key between the quotes of key, then upload this file again. */
window.FB={db:"https://qunverio-4764b-default-rtdb.asia-southeast1.firebasedatabase.app",key:""};
/* key = Web API key from Firebase Project settings > General */
